package com.poc.location;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PocLocationApplicationTests {

	@Test
	void contextLoads() {
	}

}
