package com.poc.location;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PocLocationApplication {

	public static void main(String[] args) {
		SpringApplication.run(PocLocationApplication.class, args);
	}

}
